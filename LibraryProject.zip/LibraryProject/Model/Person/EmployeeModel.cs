﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.Person
{
    public class EmployeeModel
    {
        public string UserName { get; } = 1.ToString();


        public string Password { get; } = 1.ToString();
        
        public EmployeeModel(string userName, string password, int secretCode)
        {
            UserName = userName;   
            Password = password;
        }
    }
}
