﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Book : AbstractItem
    {
        BookType bookType;
        public Book(int isbn, string name, string author, double price, DateTime dateOfRealease, string description, string publisher, double discount, BookType type) : base(isbn,name, author, price, dateOfRealease, description, publisher, discount)
        {
            bookType = type;
            //if(string.IsNullOrEmpty(name)) throw new ArgumentNullException("The Name Is Invalid");
        }


        public override string ItemType
        {
            get { return this.ToString(); }
            
        }

        public override string CategoryType
        {
            get
            {
                return bookType.ToString();
            }

        }

        public enum BookType
        {
            ActionAndAdventure,
            Fantasy,
            SciFi,
            Mystery,
            Thriller,
            Romance,
            Westerns,
            Dystopian,
            Contemporary,
            Other
        }
    }
}
