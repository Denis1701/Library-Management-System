﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public abstract class AbstractItem
    {

        public AbstractItem(int isbn, string name, string author, double price, DateTime dateOfRealease, string description, string publisher, double discount)
        {
            ISBN = isbn;
            Name = name;
            Author = author;
            Price = price;
            DateOfRealease = dateOfRealease;
            Description = description;
            Publisher = publisher;
            Discount = discount;

        }
        public string Name { get; set; }

        public string Author { get; set; }

        public double Price
        {
            get => price;
            set
            {
                if (value < 0) throw new ArgumentOutOfRangeException("You Cant Enter Nagative Price!!");
                price = value;
            }
        }

        public DateTime DateOfRealease
        {
            get => dateOfRealease;
            set
            {
                if (value > DateTime.Now) throw new ArgumentOutOfRangeException("You cant enter future date");
                if (value == null) throw new NullReferenceException("Cant Enter Null Date");
                else if (value.GetType() != typeof(DateTime)) throw new InvalidOperationException("You Have To Use DateTime");
                dateOfRealease = value;
            }
        }

        public string Description
        {
            get => description;
            set
            {
                description = value;
            }
        }

        public string Publisher { get; set; }


        public int ISBN
        {
            get => iSBN;
            set
            {
                if (value > int.MaxValue) throw new ArgumentOutOfRangeException("You Excided The Maximum Integer");
                try
                {
                    iSBN = value;
                }
                catch (InvalidCastException e)
                {
                    Console.WriteLine("Trying to convert string to INT!");
                    Console.WriteLine(e);
                }
            }
        }

        virtual public string ItemType { get; }
        virtual public string CategoryType { get; }



        public double Discount
        {
            get => discount;
            set
            {
                if (value > 100 || value < 0) throw new InvalidCastException("Can't Enter More Than 100% Discount Or Less Than 0%");
                discount = value;
            }
        }



        private double discount;
        private string description;
        private double price;
        private DateTime dateOfRealease;
        private int iSBN;
    }
}
