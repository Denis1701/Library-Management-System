﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Journal : AbstractItem
    {
        JournalType journalType;
        public Journal(int isbn, string name, string author, double price, DateTime dateOfRealease, string description, string publisher, double discount, JournalType type) : base(isbn, name, author, price, dateOfRealease, description, publisher, discount)
        {
            journalType = type;
        }

        public override string ItemType
        {
            get { return this.ToString(); }

        }
        public override string CategoryType
        {
            get
            {
                return journalType.ToString();
            }

        }


        public enum JournalType
        {
            Adventure,
            Science,
            Beauty,
            LifeStyle,
            Other
        }
      
    }
}
