﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Tests
{
    [TestClass()]
    public class ItemCollectionTests
    {
        ItemCollection library = new ItemCollection();
        

        [TestMethod()]
        public void ShowAllStockTest()
        {
            Book book1 = new Book(123456789, "Harry Poter", "J.K.Rowling", 100, DateTime.Now, "nice book", "publisher", 50, Book.BookType.Fantasy);
            Book book2 = new Book(123456788, "Harry Poter", "J.K.Rowling", 100, DateTime.Now, "nice book", "publisher", 50, Book.BookType.Fantasy);
            Book book3 = new Book(123456787, "Harry Poter", "J.K.Rowling", 100, DateTime.Now, "nice book", "publisher", 50, Book.BookType.Fantasy);
            List<AbstractItem> itemsList = new List<AbstractItem>();
            
                library.AddItem(book1);
                library.AddItem(book2);
                library.AddItem(book3);
                itemsList.Add(book1);
                itemsList.Add(book2);
                itemsList.Add(book3);
            
            List<AbstractItem> tmpList = library.ShowAllStock();
            for (int i = 0; i < itemsList.Count; i++)
            {
                Assert.AreEqual(tmpList[i], itemsList[i]);
            }


        }

        [TestMethod()]
        public void AddItemTest()
        {
            Book book = new Book(123456789, "Harry Poter", "J.K.Rowling", 100, DateTime.Now, "nice book", "publisher", 50, Book.BookType.Fantasy);
            library.AddItem(book);
            bool test = false;
            if (library.items[0].Equals(book))
            {
                test = true;
            }
            Assert.IsTrue(test);
        }
        [TestMethod()]
        public void RemoveItemTest()
        {
            Book book = new Book(123456789, "Harry Poter", "J.K.Rowling", 100, DateTime.Now, "nice book", "publisher", 50, Book.BookType.Fantasy);
            library.AddItem(book);
            bool test = false;
            library.RemoveItem(123456789);
            if(library.items.Count == 0)
            {
                test=true;
            }
            Assert.IsTrue(test);
        }
        [TestMethod()]
        public void EditItemTest()//BY ISBN
        {
            Book book1 = new Book(123456789, "Harry Poter", "J.K.Rowling", 100, DateTime.Now, "nice book", "publisher", 50, Book.BookType.Fantasy);
            Book book2 = new Book(123456789, "Harry", "Rowling", 100, DateTime.Now, "noice", "Hru", 50, Book.BookType.ActionAndAdventure);
            bool test = false;
            library.AddItem(book1);
            library.EditItem(book2);
            if(library.items[0].Equals(book2))
            {
                test = true;
            }
            Assert.IsTrue(test);

        }
        [TestMethod()]
        public void FilterTest()
        {
            Book book1 = new Book(123456789, "Harry Poter", "J.K.Rowling", 100, DateTime.Now, "nice book", "publisher", 50, Book.BookType.Fantasy);
            Book book2 = new Book(123456788, "Harry Poter", "J.K.Rowling", 100, DateTime.Now, "nice book", "publisher", 50, Book.BookType.Fantasy);
            Book book3 = new Book(123456787, "Harry Poter", "J.K.Rowling", 100, DateTime.Now, "nice book", "publisher", 50, Book.BookType.Fantasy);
            Book book4 = new Book(123456787, "", "", 80, DateTime.Now, "", "", 0, Book.BookType.ActionAndAdventure);
            bool test = false;  
            library.AddItem(book1);
            library.AddItem(book2);
            library.AddItem(book3);//3 Equals to 4 by ISBN
            List<AbstractItem> tmpList = library.Filter(book4);
            if(tmpList[0].Equals(book3)) test = true;
            Assert.IsTrue(test);
            
        }



    }
}