﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public interface IAdable
    {
        AbstractItem AddItem(AbstractItem item);
        List<AbstractItem> ShowAllStock();

        AbstractItem RemoveItem(int isbn);
        AbstractItem EditItem(AbstractItem item);
        List<AbstractItem> Filter(AbstractItem item);
    }
}
