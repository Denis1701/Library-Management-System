﻿using Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class ItemCollection : IShowable, IAdable
    {
        public List<AbstractItem> items { get; set; }

        private Hashtable item = new Hashtable() { };
        public ItemCollection()
        {
            items = new List<AbstractItem>();
            
            
        }

        public AbstractItem this[string name]
        {
            get
            {
                foreach (var item in items)
                {
                    if (item.Name == name)
                        return item;

                }
                return null;
            }

        }
        public AbstractItem this[int isbn]
        {
            get
            {
                foreach (var item in items)
                {
                    if (item.ISBN == isbn)
                        return item;
                }
                return null;
            }
        }

        public AbstractItem AddItem(AbstractItem inputItem)
        {
            if (items.Count == 0)
            {
                items.Add(inputItem);
                return inputItem;
            }
            foreach (var item in items)
            {
                if (item.ISBN == inputItem.ISBN) return null;
            }
            items.Add(inputItem);
            return inputItem;


            
        }

        public List<AbstractItem> ShowAllStock()
        {
            if (items.Count == 0) return null;
            return items;
        }

        public AbstractItem RemoveItem(int isbn)
        {
            bool flag = false;
            AbstractItem outputItem = null;
            if (items.Count == 0)
            {
                return outputItem;
            }
            foreach(var item in items)
            {
                if (item.ISBN == isbn)
                {
                    outputItem = item;
                    flag = true;
                }
            }
            if (flag) items.Remove(outputItem);
            return outputItem;
            

        }

        public AbstractItem EditItem(AbstractItem inputItem)
        {
            if (items.Count == 0) return null;
            for(int i = 0; i < items.Count; i++)
            {
                if (items[i].ISBN == inputItem.ISBN)
                {
                    items[i] = inputItem;
                }
            }
            return inputItem;
        }

        public List<AbstractItem> Filter(AbstractItem inputItem)
        {
            List<AbstractItem> listOfGoodItems = new List<AbstractItem>();
            if(items.Count == 0) return null;
            foreach (var item in items)
            {
                if (item.ISBN == inputItem.ISBN || item.Name == inputItem.Name || item.Author == inputItem.Author || item.Price == inputItem.Price || item.Publisher == inputItem.Publisher
                    || item.Description == inputItem.Description || item.Discount == inputItem.Discount)
                {
                    listOfGoodItems.Add(item);
                }

            }
            return listOfGoodItems;

        }
    }
}
