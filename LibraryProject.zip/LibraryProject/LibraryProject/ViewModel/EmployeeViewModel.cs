﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using Model;
using Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;

namespace LibraryProject.ViewModel
{
    public class EmployeeViewModel : ViewModelBase
    {

        public string Name
        {
            get => name;
            set
            {
                name = value;
                if (!Regex.IsMatch(name, "^[a-zA-Z\\s]{1,15}$")) MessageBox.Show("Please Insert Only Letters up to 15");
            }
        }
        public string ISBN
        {
            get => iSBN;
            set
            {
                iSBN = value;
                if (!Regex.IsMatch(iSBN, "^[0-9]{9}$")) MessageBox.Show("Please Insert 9 numbers");
            }
        }
        public string Author
        {
            get => author;
            set
            {
                author = value;
                if (!Regex.IsMatch(author, "^[a-zA-Z\\s]{1,25}$")) MessageBox.Show("Write The Author's Name Up To 25 Letters");
            }
        }
        public string Price
        {
            get => price;
            set
            {
                price = value;
                if (!Regex.IsMatch(price, "^[0-9]{1,9}$")) MessageBox.Show("Please Insert up to 9 numbers");
            }
        }
        public DateTime DateOfRealease { get; set; }
        public string Description
        {
            get => description;
            set
            {
                description = value;
                if (!Regex.IsMatch(description, "^[a-zA-Z\\s]{1,50}$")) MessageBox.Show("Write The Description Up To 50 Letters");
            }
        }
        public string Publisher
        {
            get => publisher;
            set
            {
                publisher = value;
                if (!Regex.IsMatch(author, "^[a-zA-Z\\s]{1,25}$")) MessageBox.Show("Write The Publisher's Name Up To 25 Letters");
            }
        }
        public string Discount
        {
            get => discount;
            set
            {
                discount = value;
                if (!Regex.IsMatch(discount, "^[0-9]{0,3}$")) MessageBox.Show("Invalid Discount Number");
            }
        }
        public bool[] IsSelectedFilter { get; set; }
        public bool IsBook
        {
            get => isBook;
            set
            {
                isBook = value;
                if (isBook) isJournal = false;
            }
        }
        public bool IsJournal
        {
            get => isJournal;
            set
            {
                isJournal = value;
                if (isJournal) isBook = false;
            }
        }

        public Journal.JournalType JournalTypeProp { get; set; }

        public Book.BookType BookTypeProp { get; set; }


        private readonly IAdable service;
        private ObservableCollection<AbstractItem> model;
        private bool isJournal;
        private bool isBook;
        private string name;
        private string iSBN;
        private string author;
        private string price;
        private string description;
        private string publisher;
        private string discount;

        public RelayCommand ShowAllCommand { get; set; }
        public RelayCommand AddItemCommand { get; set; }
        public RelayCommand RemoveItemCommand { get; set; }
        public RelayCommand EditItemCommand { get; set; }
        public RelayCommand FilterItemCommand { get; set; }
        public ObservableCollection<AbstractItem> Model
        {
            get => model; set => Set(ref model, value);
        }

        public EmployeeViewModel(ItemCollection item)
        {
            service = item;
            Model = new ObservableCollection<AbstractItem> { };
            AddItemCommand = new RelayCommand(Additem);
            ShowAllCommand = new RelayCommand(ShowAll);
            RemoveItemCommand = new RelayCommand(RemoveItem);
            EditItemCommand = new RelayCommand(EditItem);
            FilterItemCommand = new RelayCommand(FilterItem);
        }

        private void FilterItem()
        {
            Model.Clear();
            List<AbstractItem> items;
            bool pars1;
            bool pars2;
            bool pars3;
            double prc = 0;
            int isbn = 0;
            double disc = 0;
            if(Price != null) pars1 = double.TryParse(Price, out prc);
            if(ISBN != null) pars2 = int.TryParse(ISBN, out isbn);
            if(Discount != null) pars3 = double.TryParse(Discount, out disc);
            if (isBook)
            {
                Book book = new Book(isbn, Name, Author, prc, DateOfRealease, Description, Publisher, disc, BookTypeProp);
                items = service.Filter(book);
            }
            else if (isJournal)
            {
                Journal journal = new Journal(isbn, Name, Author, prc, DateOfRealease, Description, Publisher, disc, JournalTypeProp);
                items = service.Filter(journal);
            }
            else
            {
                MessageBox.Show("Choose Item Type");
                return;
            }
            if (items == null)
            {
                MessageBox.Show("No Items Accepted");
            }
            ConvertToObs(items);
        }

        private void EditItem()
        {
            Model.Clear();
            double prc;
            int isbn;
            double disc;
            bool pars1 = double.TryParse(Price, out prc);
            bool pars2 = int.TryParse(ISBN, out isbn);
            bool pars3 = double.TryParse(Discount, out disc);
            AbstractItem tmpItem;
            if (isBook && pars1 && pars2 && (pars3 || Discount == null))
            {
                Book book = new Book(isbn, Name, Author, prc, DateOfRealease, Description, Publisher, disc, BookTypeProp);
                tmpItem = service.EditItem(book);
            }
            else if (isJournal && pars1 && pars2 && (pars3 || Discount == null))
            {
                Journal journal = new Journal(isbn, Name, Author, prc, DateOfRealease, Description, Publisher, disc, JournalTypeProp);
                tmpItem = service.EditItem(journal);
            }
            else
            {
                MessageBox.Show("Check Inputs");
                return;
            }
            if (tmpItem == null)
            {
                MessageBox.Show("No Such Item To Edit - With The Same ISBN");
                return;
            }
            ConvertToObsSingleItem(tmpItem);
        }

        private void ConvertToObsSingleItem(AbstractItem item)
        {
            Model.Add(item);
        }
        private void ConvertToObs(List<AbstractItem> list)
        {
            list.ToList().ForEach(Model.Add);
        }
        
        private void RemoveItem()
        {
            Model.Clear();
            int isbn;
            bool pars1 = int.TryParse(ISBN, out isbn);
            AbstractItem item;
            if (pars1)
            {
                item = service.RemoveItem(isbn);
            }
            else
            {
                MessageBox.Show("Check ISBN");
                return;
            }
            if (item == null)//NULL OUTPUT FROM SERVICE
            {
                MessageBox.Show("No Such ISBN");
                return;
            }
            ConvertToObsSingleItem(item);

        }

        private void ShowAll()
        {
            Model.Clear();
            List<AbstractItem> tmpList = service.ShowAllStock();
            if (tmpList == null)
            {
                MessageBox.Show("Nothing To Show - I'm EMPTY");
                return;
            }
            ConvertToObs(tmpList);
        }


        private void Additem()
        {
            Model.Clear();
            double prc;
            int isbn;
            double disc;
            bool pars1 = double.TryParse(Price, out prc);
            bool pars2 = int.TryParse(ISBN, out isbn);
            bool pars3 = double.TryParse(Discount, out disc);
            AbstractItem tmpItem;
            if (isBook && pars1 && pars2 && (pars3 || Discount == null))
            {
                Book book = new Book(isbn, Name, Author, prc, DateOfRealease, Description, Publisher, disc, BookTypeProp);
                tmpItem = service.AddItem(book);
            }
            else if (isJournal && pars1 && pars2 && (pars3 || Discount == null))
            {
                Journal journal = new Journal(isbn, Name, Author, prc, DateOfRealease, Description, Publisher, disc, JournalTypeProp);
                tmpItem = service.AddItem(journal);
            }
            else
            {
                MessageBox.Show("Check Inputs");
                return;
            }

            if (tmpItem == null)//NULL OUTPUT FROM SERVICE
            {
                MessageBox.Show("ISBN Already Excist");
                return;
            }
            ConvertToObsSingleItem(tmpItem);

        }

    }


}

