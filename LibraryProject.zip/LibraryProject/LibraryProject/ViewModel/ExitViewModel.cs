﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryProject.ViewModel
{
    public class ExitViewModel : ViewModelBase
    {
        public RelayCommand ExitCommand { get; set; }
        public ExitViewModel()
        {
            ExitCommand = new RelayCommand(CloseApp);
        }

        private void CloseApp() => System.Windows.Application.Current.Shutdown();
    }
}
