﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using LibraryProject.Commands;
using LibraryProject.ViewModel.Navigators;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace LibraryProject.ViewModel
{
    public class NavigationBarViewModel : ViewModelBase, INavigator
    {
        private ViewModelBase currentViewModel;
        private ItemCollection service;

        public ViewModelBase CurrentViewModel
        {
            get => currentViewModel;
            set => Set(ref currentViewModel , value);
        }

        public ICommand UpdateCurrentViewModelCommand => new UpdateCurrentViewModelCommand(this, service);

        public NavigationBarViewModel(ItemCollection service)
        {
            this.service = service;
        }


    }
}
