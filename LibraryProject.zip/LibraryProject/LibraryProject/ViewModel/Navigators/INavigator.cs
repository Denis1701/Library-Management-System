﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryProject.ViewModel.Navigators
{
    public enum ViewType
    {
        Customer,
        Employee,
        Exit
    }
    public interface INavigator
    {
        ViewModelBase CurrentViewModel { get; set; }


    }
}
