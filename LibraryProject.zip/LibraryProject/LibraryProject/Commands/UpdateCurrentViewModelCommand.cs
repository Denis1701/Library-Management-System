﻿using LibraryProject.ViewModel;
using LibraryProject.ViewModel.Navigators;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace LibraryProject.Commands
{
    public class UpdateCurrentViewModelCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;

        private INavigator navigator;
        private ItemCollection service;

        public UpdateCurrentViewModelCommand(INavigator navigator, ItemCollection service)
        {
            this.navigator = navigator;
            this.service = service;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            if (parameter is ViewType)
            {
                ViewType viewType = (ViewType)parameter;
                switch (viewType)
                {
                    case ViewType.Customer:
                        navigator.CurrentViewModel = new CustomerViewModel(service);
                        break;
                    case ViewType.Employee:
                        navigator.CurrentViewModel = new EmployeeViewModel(service);
                        break;
                    case ViewType.Exit:
                        navigator.CurrentViewModel = new ExitViewModel();
                        break;
                    default:
                        break;
                }
            }
        }
    }
}